import React, { useContext } from 'react';
import './cart.css';
import { StoreContext } from '../../context/StoreContext';

const Cart = () => {

    const {
        cartItems,
        food_list,
        addToCart,
        removeFromCart,
        removeItem
    } = useContext(StoreContext);


    return (

        <div className="cart">

            <div className="cart-items">

                {/* =================================
                    CART HEADER
                ================================= */}

                <div className="cart-items-title">

                    <p>Items</p>

                    <p>Title</p>

                    <p>Price</p>

                    <p>Quantity</p>

                    <p>Total</p>

                    <p>Remove</p>

                </div>


                {/* =================================
                    CART PRODUCTS
                ================================= */}

                {food_list.map((item) => {

                    if (cartItems[item._id] > 0) {

                        return (

                            <div
                                key={item._id}
                                className="cart-items-title-item"
                            >

                                {/* FOOD IMAGE */}

                                <img
                                    src={item.image}
                                    alt={item.name}
                                />


                                {/* FOOD NAME */}

                                <p className="cart-item-name">
                                    {item.name}
                                </p>


                                {/* PRICE */}

                                <p className="cart-item-price">
                                    ${item.price}
                                </p>


                                {/* QUANTITY */}

                                <div className="quantity-control">

                                    <button
                                        className="quantity-btn"
                                        onClick={() =>
                                            removeFromCart(item._id)
                                        }
                                    >
                                        −
                                    </button>


                                    <span className="quantity-number">
                                        {cartItems[item._id]}
                                    </span>


                                    <button
                                        className="quantity-btn"
                                        onClick={() =>
                                            addToCart(item._id)
                                        }
                                    >
                                        +
                                    </button>

                                </div>


                                {/* TOTAL */}

                                <p className="cart-item-total">

                                    $
                                    {item.price *
                                        cartItems[item._id]}

                                </p>


                                {/* REMOVE */}

                                <div className="cart-action">

                                    <button
                                        onClick={() =>
                                            removeItem(item._id)
                                        }
                                    >
                                        Remove
                                    </button>

                                </div>

                            </div>

                        );

                    }

                    return null;

                })}

            </div>
              <div className="cart-bottom">
                <div className="cart-total">
                    <h2>cart</h2>
                    <div>
                   <div className="cart-total-detailes">
                    <p>Subtotal</p>
                    <p>{0}</p>
                   </div>
                   <hr />
                   <div className="cart-total-detailes">
                    <p>Delivery Fee</p>
                    <p>{2}</p>
                   </div>
                   <hr />
                   <div className="cart-total-detailes">
                    <p>Total</p>
                    <p>{0}</p>
                   </div>
                   </div>
                   <button>PROCED TO CHECKOUT</button>
                </div>
                <div className="car-Promocode">
                    <p>*If you have  promo code, Please Enter it here</p>
                    <div className="cart-pronocode-input">
                        <input type="text" placeholder='promo code'/>
                        <button>Submit</button>
                    </div>
                </div>
              </div>
            </div>

    );

};

export default Cart;