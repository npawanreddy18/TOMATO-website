import { createContext, useEffect, useState } from 'react';
import { food_list } from '../assets/assets';

export const StoreContext = createContext(null);

const StoreContextProvider = ({ children }) => {

    const [cartItems, setCartItems] = useState({});

    // SEARCH TEXT
    const [searchTerm, setSearchTerm] = useState("");


    // =========================================
    // ADD ITEM
    // =========================================

    const addToCart = (itemId) => {

        setCartItems((prev) => ({
            ...prev,
            [itemId]: prev[itemId]
                ? prev[itemId] + 1
                : 1
        }));

    };


    // =========================================
    // REMOVE ONE QUANTITY
    // =========================================

    const removeFromCart = (itemId) => {

        setCartItems((prev) => {

            const updatedCart = {
                ...prev
            };

            if (updatedCart[itemId]) {

                updatedCart[itemId] =
                    updatedCart[itemId] - 1;

                if (updatedCart[itemId] <= 0) {
                    delete updatedCart[itemId];
                }

            }

            return updatedCart;

        });

    };


    // =========================================
    // REMOVE ENTIRE ITEM
    // =========================================

    const removeItem = (itemId) => {

        setCartItems((prev) => {

            const updatedCart = {
                ...prev
            };

            delete updatedCart[itemId];

            return updatedCart;

        });

    };


    // =========================================
    // DEBUG
    // =========================================

    useEffect(() => {

        console.log("Cart:", cartItems);

    }, [cartItems]);


    // =========================================
    // CONTEXT VALUE
    // =========================================

    const contextValue = {

        food_list,

        cartItems,
        setCartItems,

        addToCart,
        removeFromCart,
        removeItem,

        // SEARCH
        searchTerm,
        setSearchTerm

    };


    return (

        <StoreContext.Provider value={contextValue}>

            {children}

        </StoreContext.Provider>

    );

};

export default StoreContextProvider;